import ui

# The button's action:
def button_tapped(sender):
    def animation():
        sender.alpha = 0.0 # fade out
    ui.animate(animation, duration=1.0)

# Set up and present a view with a single button:
v = ui.View(background_color='white')
button = ui.Button(title='Tap me!')
button.action = button_tapped
v.add_subview(button)
v.present('sheet')
