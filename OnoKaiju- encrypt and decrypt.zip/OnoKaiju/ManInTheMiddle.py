import time

#import ui

import cb

#from LoadingViewFull import *
#from LoadingViewSimple import *

#from ConsoleView import *

from iCE40UltraWearableBLEDelegate import *


from ViewSwitcher import *


switcher = ViewSwitcher()

time.sleep(1)

switcher.view_index = (switcher.view_index - 1) % len(switcher.view_array)
switcher.switch_views()


cb.set_central_delegate( iCE40UltraWearableBLEDelegate() )
print('Looking for iCE40UW...')

# Look for Kaiju and connect
cb.scan_for_peripherals()


while 1:
	pass
	# if switcher.view_array[switcher.view_index].close:
	# 	switcher.view_index = (switcher.view_index - 1) % len(switcher.view_array)
	# 	switcher.switch_views()
# mv = LoadingView()
# mv1 = MyView1()
#
# currentView = 'Loading'
#
# changeView = False
#
# # mv.present('fullscreen', hide_title_bar=True, title_bar_color=None)
# mv.present(style='Fullscreen', animated=False, hide_title_bar=True, title_bar_color='black')
#
# time.sleep(1)

# ui.animate(mv.fadeOut, duration=1.0)
