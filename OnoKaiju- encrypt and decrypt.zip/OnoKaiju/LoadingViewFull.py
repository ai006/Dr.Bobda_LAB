import ui

class LoadingViewFull (ui.View):
	def __init__(self):
		self.close = False

	def draw(self):
		splashscreen = ui.Image.named('FullLogo.PNG')
		# self.alpha = 0.0
		splashscreen.draw(0, 0, self.width, self.height)
		# ui.animate(self.fadeIn, duration=1.5)

		#img = ui.Image.named('Icons/btc.png')
		#img.draw(0, 0, self.width, self.height)


	def fadeOut(self):
		self.close = False
		self.alpha = 0.0

	def fadeIn(self):
		self.alpha = 1.0

	def touch_began(self, touch):
		self.close = True
