import time

import ui

from LoadingViewFull import *
from LoadingViewSimple import *

from ConsoleView import *


class ViewSwitcher(ui.View):
    def __init__(self):
        self.view_names = ['LoadingViewFull', 'LoadingViewSimple']
        self.view_index = -1
        self.view_array = []


        # show empty white view
        self.background_color = 'black'
        # back.action = self.bt_back
        # forward.action = self.bt_forward
        # self.left_button_items = [space, back]
        # self.right_button_items = [space, space, forward]
        self.present(style='Fullscreen', animated=False, hide_title_bar=True, title_bar_color='black')

        self.view_index += 1
        self.view_array.append(LoadingViewFull())
        self.view_array[self.view_index].frame = self.frame
        self.add_subview(self.view_array[self.view_index])

        # self.view_index += 1
        # self.view_array.append(LoadingViewSimple())
        # self.view_array[self.view_index].frame = self.frame
        # self.add_subview(self.view_array[self.view_index])

        self.view_index += 1
        self.view_array.append(ConsoleView())
        self.view_array[self.view_index].frame = self.frame
        self.add_subview(self.view_array[self.view_index])
        self.view_array[self.view_index].hidden = True

        self.view_index = 0


    def switch_views(self):
        for i in range(len(self.view_array)):
            ui.animate(self.view_array[i].fadeOut, duration=0.75)
            time.sleep(1)
            self.view_array[i].hidden = True


        self.view_array[self.view_index].hidden = False
        ui.animate(self.view_array[self.view_index].fadeIn, duration=0.75)
        # self.view_array[self.view_index].fadeIn()
        self.name = self.view_names[self.view_index]

    def all_action(self, sender):
        print('action from ' + sender.name)
