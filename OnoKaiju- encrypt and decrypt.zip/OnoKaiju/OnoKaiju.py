import time 

#import ui

import cb

#from LoadingViewFull import *
#from LoadingViewSimple import *

#from ConsoleView import *

from iCE40UltraWearableBLEDelegate import *


from ViewSwitcher import *


#switcher = ViewSwitcher()

time.sleep(1)

#switcher.view_index = (switcher.view_index - 1) % len(switcher.view_array)
#switcher.switch_views()

BLEDelegate = iCE40UltraWearableBLEDelegate()
cb.set_central_delegate( BLEDelegate )
print('Looking for iCE40UW...')

# Look for Kaiju and connect
cb.scan_for_peripherals()


while 1:

	
	#switcher.view_array[1].connectionStatus.text = BLEDelegate.connectionState

	if BLEDelegate.connectionState is 'Disconnected':
		print('disconnected')
		cb.scan_for_peripherals()
	else:
		
	
		#while 1:
			#print('trigger')
			flag = input()
	# Console view action
			if flag == '':
	
	#if switcher.view_array[1].startCommunicationFlag:
				print('starting communication...\n')
				BLEDelegate.startSecureCommunication()
				
				flag = 0
				#switcher.view_array[1].startCommunicationFlag = False
				
	# pass
	# if switcher.view_array[switcher.view_index].close:
	# 	switcher.view_index = (switcher.view_index - 1) % len(switcher.view_array)
	# 	switcher.switch_views()
# mv = LoadingView()
# mv1 = MyView1()
#
# currentView = 'Loading'
#
# changeView = False
#
# # mv.present('fullscreen', hide_title_bar=True, title_bar_color=None)
# mv.present(style='Fullscreen', animated=False, hide_title_bar=True, title_bar_color='black')
#
# time.sleep(1)

# ui.animate(mv.fadeOut, duration=1.0)
