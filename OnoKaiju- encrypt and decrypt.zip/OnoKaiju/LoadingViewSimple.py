import ui

class LoadingViewSimple (ui.View):
	def __init__(self):
		self.close = False

	def draw(self):
		splashscreen = ui.Image.named('SimpleLogo.PNG')
		splashscreen.draw(0, 0, self.width, self.height)
		
		#img = ui.Image.named('Icons/btc.svg')
		#img.draw(0, 0, self.width, self.height)

	def fadeOut(self):
		self.close = False
		self.alpha = 0.0

	def fadeIn(self):
		self.alpha = 1.0

	def touch_began(self, touch):
		self.close = True
