import ui
import canvas


class ConsoleView (ui.View):
	def __init__(self):
		self.close = False
		self.textView = None
		self.textViewDelegate = None

		self.background_color = 'white'

		self.startCommunicationFlag = False

		self.startCommunicationButton = None



		# self.view_array[0]['btn_Okay'].action = self.all_action


	def triggerStartCommunication(self):
		self.startCommunicationFlag = True

	def draw(self):
		titleLogo = ui.Image.named('TitleBarLogo.PNG')
		self.alpha = 0.0

		titleBackground = ui.Image.named('Black.PNG')
		titleBackground.draw(0, 0, 450, 175)

		# img = ui.Image.named('Icons/btc.png')
		# img.draw(50, 200, 60, 60)
		# img.bring_to_front()

		logoScale = 0.20
		titleLogo.draw(70, 50, titleLogo.size[0] * logoScale, titleLogo.size[1] * logoScale)
		ui.animate(self.fadeIn, duration=1.0)

		#titleBackground = ui.Image.named('Black.PNG')
		#titleBackground.draw(0, 0, 450, 200)

		#canvas.set_size(400,200)
		#canvas.draw_rect(0,0,450,200)

		iconBTC = ui.Image.named('Icons/btc.png')
		iconBTC.draw(40, 200, 60, 60)

		self.amountBTC = ui.TextView()
		self.amountBTC.scroll_enabled = False
		self.amountBTC.editable = False
		self.amountBTC.frame = (120, 205, 300, 40)
		self.amountBTC.font = ('<system-bold>', 30)
		self.amountBTC.text = '0.1572390847'
		self.amountBTC.delegate = ConsoleTextDelegate()
		self.add_subview(self.amountBTC)

		iconBCH = ui.Image.named('Icons/bch.png')
		iconBCH.draw(40, 300, 60, 60)

		self.amountBCH = ui.TextView()
		self.amountBCH.scroll_enabled = False
		self.amountBCH.editable = False
		self.amountBCH.frame = (120, 305, 300, 40)
		self.amountBCH.font = ('<system-bold>', 30)
		self.amountBCH.text = '0.4002490874'
		self.amountBCH.delegate = ConsoleTextDelegate()
		self.add_subview(self.amountBCH)

		iconETH = ui.Image.named('Icons/eth.png')
		iconETH.draw(40, 400, 60, 60)

		self.amountETH = ui.TextView()
		self.amountETH.scroll_enabled = False
		self.amountETH.editable = False
		self.amountETH.frame = (120, 405, 300, 40)
		self.amountETH.font = ('<system-bold>', 30)
		self.amountETH.text = '0.0572234847'
		self.amountETH.delegate = ConsoleTextDelegate()
		self.add_subview(self.amountETH)

		iconLTC = ui.Image.named('Icons/ltc.png')
		iconLTC.draw(40, 500, 60, 60)

		self.amountLTC = ui.TextView()
		self.amountLTC.scroll_enabled = False
		self.amountLTC.editable = False
		self.amountLTC.frame = (120, 505, 300, 40)
		self.amountLTC.font = ('<system-bold>', 30)
		self.amountLTC.text = '2.4002591874'
		self.amountLTC.delegate = ConsoleTextDelegate()
		self.add_subview(self.amountLTC)

		# self.startCommunicationButton = ui.Button()
		# self.startCommunicationButton.image = ui.Image.named('test:Peppers')
		self.startCommunicationButton = ui.Image.named('typb:Anchor')
		self.startCommunicationButton.draw(140, 650, 100, 100)
		# self.startCommunicationButton.action = self.triggerStartCommunication
		# self.add_subview(self.startCommunicationButton)

		self.connectionStatus = ui.TextView()
		self.connectionStatus.scroll_enabled = False
		self.connectionStatus.editable = False
		self.connectionStatus.alignment = ui.ALIGN_CENTER
		self.connectionStatus.frame = (0, 740, 380, 40)
		self.connectionStatus.font = ('<system-bold>', 20)
		self.connectionStatus.text = 'Disconnected'
		self.connectionStatus.delegate = ConsoleTextDelegate()
		self.add_subview(self.connectionStatus)



	def fadeOut(self):
		self.close = False
		self.alpha = 0.0

	def fadeIn(self):
		self.alpha = 1.0

	def touch_began(self, touch):
		self.close = True

		print(touch.location[0])
		print(touch.location[1])

		self.triggerStartCommunication()


class ConsoleTextDelegate (object):
    def textview_should_begin_editing(self, textview):
        return True
    def textview_did_begin_editing(self, textview):
        pass
    def textview_did_end_editing(self, textview):
        pass
    def textview_should_change(self, textview, range, replacement):
        return True
    def textview_did_change(self, textview):
        pass
    def textview_did_change_selection(self, textview):
        pass
