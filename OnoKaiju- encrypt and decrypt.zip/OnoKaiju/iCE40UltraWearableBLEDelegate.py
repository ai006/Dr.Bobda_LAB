import cb
import threading
import binascii
from Crypto.Cipher import AES

class iCE40UltraWearableBLEDelegate (object):
	def __init__(self):
		self.peripheral = None
		self.uuidTX = None
		self.uuidRX = None

		self.writeTimer = None
		self.TX_char = None

		self.command = None

		self.connectionState = 'Idle'
		
		self.msg = b''
		#self.msg.encode()
		self.j = 0
		self.x = 0
		self.passed = 0
		self.key = '00000000000000000000000000000000'
		#print('\tkey: ',key)
		self.key = self.key.encode()
			#key = b'00000000000000000000000000000000'
		self.key = binascii.unhexlify(self.key)
		self.cipher = starter(self.key)

	def writeTX(self):
		print('Writing')
	# 	self.peripheral.read_characteristic_value(self.currentTimeCharacteristic)
	# 	# self.readScheduler.enter(10, 1, self.readTime)


		if self.TX_char is not None:
			self.peripheral.write_characteristic_value(self.TX_char, b'\x00', True)

			self.writeTimer = threading.Timer(2.0, self.writeTX)
			self.writeTimer.start()


	def startSecureCommunication(self):
		status = 'Starting secure communication...\n'
		# print('Writing')
		
		if self.TX_char is not None:
			
			self.connectionState = 'Starting'
		
			i = 0
			
			#key = '00000000000000000000000000000000'
			print('\tkey: ',self.key)
			#key = key.encode()
			#key = b'00000000000000000000000000000000'
			#key = binascii.unhexlify(key)
			#cipher = starter(key)
			
			plaintext = 'Hello world this'
			print('\tplaintext: ',plaintext)
			plaintext = plaintext.encode()
			encrypted = encrypt(plaintext,self.cipher)
			print('\tEncrypted text: ', encrypted)
						
			print('\nsending encrypted text...')
			str = encrypted
		
		while i<16:
			#print(bytes([str[i]]))
			#print(str[i])
			self.peripheral.write_characteristic_value(self.TX_char, bytes([str[i]]), True)
			i += 1
			# Show Yellow LED (Authenticating)
			self.connectionState = 'Authenticating'
			#self.peripheral.write_characteristic_value(self.TX_char, b'\x01', True) # Red on
			#self.peripheral.write_characteristic_value(self.TX_char, b'\x00', True) # Green on

			# Show Green LED (Secure communication)
			self.connectionState = 'Secured'
			#self.peripheral.write_characteristic_value(self.TX_char, b'\x01', True) # Red off
			#self.peripheral.write_characteristic_value(self.TX_char, b'\x03', True) # Green on
		#print('done 1')

	def did_discover_peripheral(self, p):
		if p.uuid == 'E01FAB28-8F70-EB91-C2BB-BC76478F61CA' and not self.peripheral:
			# if p:
			print('\tDiscovered.')
			self.peripheral = p
			cb.connect_peripheral(self.peripheral)
				
		#print('done 2')

	def did_connect_peripheral(self, p):
		print('\tConnected.')

		self.connectionState = 'Connected'

		#print('\tLooking for services...')
		p.discover_services()
		#print('done 3')

	def did_disconnect_peripheral(self, p, error):
		print('Disconnected, error: %s' % (error,))
		self.peripheral = None
		self.uuidTX = None
		self.uuidRX = None

		self.writeTimer = None
		self.TX_char = None

		self.connectionState = 'Disconnected'
		#print('done 4')

	def did_discover_services(self, p, error):
		for s in p.services:
			if '0001' in s.uuid:
				print('\tFound UART service.')
				p.discover_characteristics(s)
		#print('done 5')


	def did_discover_characteristics(self, s, error):
		
		for c in s.characteristics:
			if '0002' in c.uuid:
				self.uuidTX = c.uuid
				self.TX_char = c

				print('\t\tFound TX characteristic.')

				if c.properties is cb.CH_PROP_WRITE_WITHOUT_RESPONSE:
					print('\t\t\tWrite enabled w/o response.')
				if c.properties is cb.CH_PROP_WRITE:
					print('\t\t\tWrite enabled w/ response.')
				if c.properties is (cb.CH_PROP_WRITE_WITHOUT_RESPONSE | cb.CH_PROP_WRITE):
					print('\t\t\tWrite enabled.')

				#self.peripheral.read_characteristic_value(c)


				#self.peripheral.set_notify_value(c, True)
				#value = chr(0x00) + chr(0x01)
				#print(str(value))

				# Set the baud rate for BLE-FPGA UART module
				#self.peripheral.write_characteristic_value(c, b'\x42\x52\x34\x38\x30\x30', True)
				self.peripheral.write_characteristic_value(c, b'\x42\x52\x34\x38\x30\x30', True) # BR4800
				# self.peripheral.write_characteristic_value(c, b'\x42\x31\x31\x35\x32\x30\x30', True) #
				#self.peripheral.write_characteristic_value(c, chr(0x01), True)

				# self.writeTimer = threading.Timer(2.0, self.writeTX)
				# self.writeTimer.start()

				# self.startSecureCommunication()
				#self.peripheral.write_characteristic_value(self.TX_char, b'\x00', True) # Red off
				#self.peripheral.write_characteristic_value(self.TX_char, b'\x02', True) # Green off

				#self.peripheral.write_characteristic_value(c, chr(0x01), True)
				#self.peripheral.write_characteristic_value(c, chr(0x56), True)

			elif '0003' in c.uuid:
				self.uuidRX = c.uuid

				print('\t\tFound RX characteristic.')

				if c.properties is cb.CH_PROP_NOTIFY:
					print('\t\t\tNotify enabled.')
					self.peripheral.set_notify_value(c, True)

				#self.peripheral.read_characteristic_value(c)


			#self.peripheral.write_characteristic_value(c, b"\x02\xFF", True)

			else:
				print('\t\tFound unknown charcteristic: ' + c.uuid)
				#self.peripheral.write_characteristic_value(c, b"\xFF", True)
			#print(c.properties)


			# if c.uuid == '6E400002-B5A3-F393-E0A9-E50E24DCCA9E':
			# 	print('Found Characteristic ' + c.uuid)
			# 	print('Writing to write enabled char')
			# 	self.peripheral.write_characteristic_value(c, b"\xFF", True)

			# if c.uuid == '6E400003-B5A3-F393-E0A9-E50E24DCCA9E':
			# 	print('Found Characteristic ' + c.uuid)
			# 	print('Writing to notify characteristic')
			# 	self.peripheral.write_characteristic_value(c, b"\xFF", True)
		#print('\npress "Enter" to begin communication')

	def did_write_value(self, c, error):
		#print('j :',self.j)
		self.j += 1
		if c.uuid == self.uuidTX:
			if error is not None:
				print('Error: %s' % (error,))
			#print('\tTX: Wrote value, reading back...1')
			a = self.peripheral.read_characteristic_value(c)
			print(a.value)

		elif c.uuid == self.uuidRX:
			print('\tRX: Wrote value, reading back...2')
			self.peripheral.read_characteristic_value(c)
		#print('done 7')



	def did_update_value(self, c, error):
		#print('x :',self.x)
		self.x += 1
		#if c.uuid == self.uuidTX:
		#	print("\tTX update: ", end="")
		#	print(c.value)
		#	hexData = c.value.hex()
		#	print(hexData)
		
		if c.uuid == self.uuidRX:
		#	print("\tRX update: ", end="")
			#print(binascii.hexlify(c.value))
			#print('the value:',c.value)
			#self.msg = self.msg + c.value
			if(self.passed == 2):
				self.msg = b"".join([self.msg,c.value])
				print('ice40 encrypted: ',self.msg)
				self.passed = 0
				#key1 = '00000000000000000000000000000000'
				#key1 = key1.encode()
				#key1 = binascii.unhexlify(key1)
				#cipher = starter(key1)
				decrypted = decrypt(self.msg,self.cipher)
				decrypted = decrypted.decode()
				print('ice40 decrypted message: ',decrypted)
				self.msg = b''
				print('\n\n-------------------------------------------------')
				
				
				
			elif(self.passed == 1):
				self.msg = b"".join([self.msg,c.value])
				text = self.msg.decode()
				print('ice40 decrypted: ',text)
				self.passed += 1
				self.msg = b''
				
			elif(self.passed == 0):
				self.msg = b"".join([self.msg,c.value])
				print('ice40 sent: ',self.msg)
				self.msg = b''
				self.passed += 1
				#print(binascii.hexlify(c.value))
			
			
			#self.passed = True
		#else:
		#	print('Characteristic Update ' + c.uuid)
		#	print(c.value)
		#print('done 8')

	
		

def starter(key):
    bs = 16
    c = AES.new(key, AES.MODE_ECB)
    #print ('cipher: ' , c)
    return c

def encrypt(raw,cipher):
	print('\nencrypting plaintext...')
	#bs = 16


	encrypted = cipher.encrypt(raw)
	#print('1- ', encrypted)
	#encrypted = binascii.hexlify(encrypted)
	#print('2- ', encrypted)
	return(encrypted)

def decrypt(raw,cipher):
	print('\ndecrypting...\n')
	#print('raw: ',raw)
	
	#decoded = binascii.unhexlify(raw)
	decrypted = cipher.decrypt(raw)
	return (decrypted)

def _pad(s,bs):
    return s + (bs - len(s) % bs) * chr(bs - len(s) % bs)

def _unpad(s):
    return s[:-ord(s[len(s)-1:])]
